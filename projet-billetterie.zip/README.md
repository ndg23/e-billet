# Gestion de Billetterie

Application de gestion de billetterie développée avec Spring Boot.

## Technologies utilisées

- Java 17
- Spring Boot 3.4.0
- PostgreSQL
- Thymeleaf
- TailwindCSS

## Installation

1. Cloner le projet : 