ALTER TABLE users 
ADD COLUMN active boolean DEFAULT true; 