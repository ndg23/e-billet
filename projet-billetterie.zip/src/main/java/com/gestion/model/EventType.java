package com.gestion.model;

public enum EventType {
    CONCERT,
    SPORTS,
    THEATER,
    CONFERENCE,
    EXHIBITION,
    OTHER
} 