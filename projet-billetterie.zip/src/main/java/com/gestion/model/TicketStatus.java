package com.gestion.model;

//TicketStatus.java (Optionnel - pour une gestion plus stricte des statuts)

public enum TicketStatus {
 ACTIVE,
 USED,
 CANCELLED
}