package com.gestion.exception;



//InsufficientSeatsException.java
public class InsufficientSeatsException extends RuntimeException {
 public InsufficientSeatsException(String message) {
     super(message);
 }
}
